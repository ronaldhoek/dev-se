<?php
namespace Vcl\Imaging\pngimage;

class TPngImage extends \Ct\RTTI\RTTIObject {
	
	public function __construct() {
		parent::__construct(RTTICreateObject('Vcl.Imaging.pngimage.TPngImage', [], false));
	}
	
}
?>