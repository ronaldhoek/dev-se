<?php
namespace System\Classes;

class TStringList extends \ct\rtti\RTTIObject {
	
	public function __construct() {
		parent::__construct(RTTICreateObject('System.Classes.TStringList', [], false));
	}
	
}
?>