<?php
namespace System\SysUtils;

class TOSVersion extends \CT\RTTI\RTTIRecord {
	
	public static $qualifiedName = "System.SysUtils.TOSVersion";
	
}
?>